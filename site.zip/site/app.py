from flask import Flask, render_template, request
from jinja2 import FileSystemLoader, Environment

app = Flask(__name__, template_folder='templates')

f = FileSystemLoader('templates')
env = Environment(loader=f)

tm = env.get_template('index.html')
msg = tm.render()
tm = env.get_template('data.html')
msg1 = tm.render()


@app.route('/')
def hello2():
    return msg


@app.route('/index.html')
def hello():
    return msg


@app.route('/data.html')
def hello1():
    return msg1

@app.route('/calc')
def find_university():
    university = ['ИТМО', 'ГУАП']
    return render_template('calc.html', vuzi=university)


sql = '''SELECT University.full_name, subjects.name from University
JOIN enterys_subjects
on University.id = enterys_subjects.university_id
JOIN subjects
ON subjects.id = enterys_subjects.subject_id
'''

if __name__ == "__main__":
    app.run (host = "127.0.0.1", port = 9566)
