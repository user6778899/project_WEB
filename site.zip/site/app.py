from flask import Flask, render_template

app = Flask(__name__, template_folder='templates')


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/index.html')
def index1():
    return render_template('index.html')


@app.route('/data.html')
def data():
    return render_template('data.html')


@app.route('/calc.html')
def calc():
    return render_template('calc.html')


@app.route('/proof.html')
def proof():
    return render_template('proof.html')


@app.route('/trans_ballov.html')
def trans_ballov():
    return render_template('trans_ballov.html')


@app.route('/vuzi.html')
def vuzi():
    return render_template('vuzi.html')


@app.route('/balli.html')
def balli():
    return render_template('balli.html')


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=9566)
